def greet(name: str) -> str:
    return f"Hello, {name}! This came from mypackage."